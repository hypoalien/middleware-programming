//AANISET1@ASU.EDU
//ANUDEEP ANISETTY
const mongoose = require('mongoose');
const { toJSON } = require('./plugins');

const loanSchema = mongoose.Schema(
  {
    customerId: {
      type: String,
      required: false,
    },
    customerName: {
        type: String,
        required: false,
      },
      customerEmail: {
      type: String,
      required: false,
    },
    loanId: {
        type: Number,
        required: false,
      },
      loanAmount: {
        type: String,
        required: false,
      },
      loanIssueDate: {
        type: String,
        required: false,
      },
      loanStatus: {
        type: String,
        enum: ['Open', 'processing', 'Defaulted', 'Close'],
        required: false,
      },

      paymentId: {
        type: Number,
        required: false,
      },
      paymentAmount: {
        type: String,
        required: false,
      },
      paymentDate: {
        type: String,
        required: false,
      },
  },
  {
    timestamps: true,
  }
);

loanSchema.plugin(toJSON);

const Loan = mongoose.model('Loan', loanSchema);

module.exports = Loan;
