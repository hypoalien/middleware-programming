//AANISET1@ASU.EDU
//ANUDEEP ANISETTY
const path = require("path");
const dotenv = require("dotenv");
dotenv.config({ path: path.join(__dirname, "../.env") });
const { loans, updateLoan } = require("../data/loan.json");
const LoanDbContext = require("../databseManager/loanDBContext");
const { ObjectId } = require("mongodb");

const dbUrl = process.env.DATABASE;
const dbName = process.env.DB_NAME;
const collecConName = "loans";
const id = new ObjectId("65d2ea60a4e9a6d646a282f4");


const createLoan = async () => {
  const loanDbContext = new LoanDbContext(dbUrl, dbName);
  loanDbContext
    .insertSampleData(collecConName, loans)
    .then(() => loanDbContext.close())
    .catch((error) => console.error(error));
};
const updateLoanById = async ( ) => {
  const loanDbContext = new LoanDbContext(dbUrl, dbName);
  loanDbContext
    .updateLoanById(collecConName, id, updateLoan)
    .then(() => loanDbContext.close())
    .catch((error) => console.error(error));
};
const DeleteLoan = async () => {
  const loanDbContext = new LoanDbContext(dbUrl, dbName);
  loanDbContext
    .deleteLoanById(collecConName, id)
    .then(() => loanDbContext.close())
    .catch((error) => console.error(error));
};
const getAllLoans = async () => {
  const loanDbContext = new LoanDbContext(dbUrl, dbName);
  loanDbContext
    .getAllLoans(collecConName)
    .then(() => loanDbContext.close())
    .catch((error) => console.error(error));
};

module.exports = {
  createLoan,
  getAllLoans,
  updateLoanById,
  DeleteLoan,
};
