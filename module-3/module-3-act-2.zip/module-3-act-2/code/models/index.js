module.exports.Loan = require('./loan.model');

