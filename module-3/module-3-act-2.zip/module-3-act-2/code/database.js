const { MongoClient } = require("mongodb");
const uri =
  "mongodb+srv://aaniset1:epStJmBHfmn5cM9f@cluster0.umozrq3.mongodb.net/";

function connect() {
  const client = new MongoClient(uri);
  client.connect((err) => {
    if (err) {
      console.error("Database connection failed", err);
      return;
    }
    console.log("Connected to MongoDB");
    client.close();
  });
}

connect()

//Aaniset1@asu.edu
//Anudeep Anisetty