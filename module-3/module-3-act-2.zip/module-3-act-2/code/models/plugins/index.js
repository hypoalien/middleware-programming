module.exports.toJSON = require('./toJSON.plugin');
