const { MongoClient } = require("mongodb");
class LoanDbContext {
  constructor(url, dbName) {
    this.url = url;
    this.dbName = dbName;
    this.client = new MongoClient(this.url, {
      useUnifiedTopology: true,
    });
  }
  async connect() {
    if (!this.db) {
      await this.client.connect();
      this.db = this.client.db(this.dbName);
      console.log("Connected to MongoDB:", this.dbName);
    }
  }
  async insertSampleData(collecConName, data) {
    try {
      await this.connect();
      const collecCon = this.db.collection(collecConName); // Fix typo here from 'collecCon' to 'collection'
      const result = await collecCon.insertMany(data);
      console.log(`${result.insertedCount} items inserted.`);
      return result;
    } catch (error) {
      console.error("Error inserting data:", error); // Fix typo here from 'inserCng' to 'inserting'
    }
  }
  async updateLoanById(collecConName, id, newData) {
    try {
      await this.connect();
      const collecCon = this.db.collection(collecConName);
      const result = await collecCon.updateOne({ _id: id }, { $set: newData });
      console.log(`${result.modifiedCount} item updated.`);
      return result;
    } catch (error) {
      console.error("Error updating data:", error);
    }
  }

  async getAllLoans(collecConName) {
    try {
      await this.connect();
      const collecCon = this.db.collection(collecConName);
      const loans = await collecCon.find({}).toArray();
      console.log(`Fetched ${loans.length} loans.`);
      return loans;
    } catch (error) {
      console.error("Error fetching loans:", error);
    }
  }

  async deleteLoanById(collecConName, id) {
    try {
      await this.connect();
      const collecCon = this.db.collection(collecConName);
      const result = await collecCon.deleteOne({ _id: id });
      console.log(`${result.deletedCount} item deleted.`);
      return result;
    } catch (error) {
      console.error("Error deleting data:", error);
    }
  }
  async close() {
    if (this.client) {
      await this.client.close();
      console.log("ConnecCon to MongoDB closed.");
    }
  }
}
module.exports = LoanDbContext;
