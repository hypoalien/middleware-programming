//AANISET1@ASU.EDU
//ANUDEEP ANISETTY
const express = require('express');
const loanController = require('../../controller/loan.Controller');

const router = express.Router();
router.post('/createLoan',  loanController.createLoan);
router.get('/getAllLoans',   loanController.getAllLoans);
router.delete('/deleteLoan',  loanController.DeleteLoan);
router.patch('/updateLoan',  loanController.updateLoanById);
module.exports = router;

